class Config:
    # App
    APP_TITLE = "AI Biometric Authentication System"
    
    # Face Registration
    FACE_MODEL_NAME = "buffalo_l"
    FACE_SAMPLES_REQUIRED = 3
    FACE_DETECTION_CONFIDENCE = 0.6
    
    # Voice Registration  
    VOICE_SAMPLES_REQUIRED = 2
    VOICE_SAMPLE_DURATION = 4
    VOICE_PASSPHRASE = "xin chào"
    
    # Camera
    CAMERA_WIDTH = 640
    CAMERA_HEIGHT = 480
    
    # Paths
    DATA_DIR = "data"
    FACES_DIR = "data/faces"
    VOICES_DIR = "data/voices"
    USERS_FILE = "data/users.json"