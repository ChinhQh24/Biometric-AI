import json
import os
import numpy as np
from datetime import datetime
from config import Config

class UserDatabase:
    def __init__(self):
        self.users_file = Config.USERS_FILE
        self.faces_dir = Config.FACES_DIR
        self.voices_dir = Config.VOICES_DIR
        self.users = self._load_users()
        # Thêm callback để thông báo khi dữ liệu thay đổi
        self.on_data_changed = None
    
    def _load_users(self):
        """Tải dữ liệu users từ file JSON"""
        if os.path.exists(self.users_file):
            try:
                with open(self.users_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"❌ Lỗi đọc file users: {e}")
                return {}
        return {}
    
    def _save_users(self):
        """Lưu dữ liệu users vào file JSON"""
        try:
            os.makedirs(os.path.dirname(self.users_file), exist_ok=True)
            with open(self.users_file, 'w', encoding='utf-8') as f:
                json.dump(self.users, f, ensure_ascii=False, indent=2)
            
            # Thông báo dữ liệu đã thay đổi (chỉ khi callback tồn tại)
            if self.on_data_changed:
                self.on_data_changed()
                
            return True
        except Exception as e:
            print(f"❌ Lỗi lưu file users: {e}")
            return False
    
    def user_exists(self, user_id):
        """Kiểm tra user có tồn tại không"""
        return user_id in self.users
    
    def create_user(self, user_id, user_info=None):
        """Tạo user mới"""
        if self.user_exists(user_id):
            return False, f"User '{user_id}' đã tồn tại!"
        
        default_info = {
            'full_name': user_info.get('full_name', ''),
            'email': user_info.get('email', ''),
            'phone': user_info.get('phone', ''),
            'created_at': self._get_timestamp(),
            'face_samples': 0,
            'voice_samples': 0,
            'face_embeddings': [],
            'voice_samples_files': []
        }
        
        self.users[user_id] = {**default_info, **(user_info or {})}
        success = self._save_users()
        
        if success:
            return True, f"Đã tạo user '{user_id}' thành công!"
        else:
            return False, "Lỗi khi lưu thông tin user!"
    
    def update_user_face(self, user_id, embedding_file):
        """Cập nhật thông tin khuôn mặt cho user"""
        if not self.user_exists(user_id):
            return False, "User không tồn tại!"
        
        if embedding_file not in self.users[user_id]['face_embeddings']:
            self.users[user_id]['face_embeddings'].append(embedding_file)
            self.users[user_id]['face_samples'] = len(self.users[user_id]['face_embeddings'])
            self.users[user_id]['last_face_update'] = self._get_timestamp()
        
        success = self._save_users()
        return success, f"Đã cập nhật {self.users[user_id]['face_samples']} mẫu khuôn mặt"
    
    def update_user_voice(self, user_id, voice_file):
        """Cập nhật thông tin giọng nói cho user"""
        if not self.user_exists(user_id):
            return False, "User không tồn tại!"
        
        if voice_file not in self.users[user_id]['voice_samples_files']:
            self.users[user_id]['voice_samples_files'].append(voice_file)
            self.users[user_id]['voice_samples'] = len(self.users[user_id]['voice_samples_files'])
            self.users[user_id]['last_voice_update'] = self._get_timestamp()
        
        success = self._save_users()
        return success, f"Đã cập nhật {self.users[user_id]['voice_samples']} mẫu giọng nói"
    
    def get_user_info(self, user_id):
        """Lấy thông tin user"""
        if not self.user_exists(user_id):
            return None
        return self.users[user_id]
    
    def get_user_registration_status(self, user_id):
        """Lấy trạng thái đăng ký của user"""
        if not self.user_exists(user_id):
            return None
        
        user = self.users[user_id]
        return {
            'user_id': user_id,
            'face_samples': user['face_samples'],
            'voice_samples': user['voice_samples'],
            'face_complete': user['face_samples'] >= Config.FACE_SAMPLES_REQUIRED,
            'voice_complete': user['voice_samples'] >= Config.VOICE_SAMPLES_REQUIRED,
            'fully_registered': (user['face_samples'] >= Config.FACE_SAMPLES_REQUIRED and 
                               user['voice_samples'] >= Config.VOICE_SAMPLES_REQUIRED),
            'created_at': user.get('created_at', ''),
            'last_face_update': user.get('last_face_update', ''),
            'last_voice_update': user.get('last_voice_update', '')
        }
    
    def get_all_users(self):
        """Lấy danh sách tất cả users"""
        return list(self.users.keys())
    
    def get_user_face_embeddings(self, user_id):
        """Lấy tất cả embeddings khuôn mặt của user"""
        if not self.user_exists(user_id):
            return []
        
        embeddings = []
        for embedding_file in self.users[user_id]['face_embeddings']:
            try:
                embedding = np.load(embedding_file)
                embeddings.append(embedding)
            except Exception as e:
                print(f"❌ Lỗi đọc embedding file {embedding_file}: {e}")
        
        return embeddings
    
    def get_user_voice_files(self, user_id):
        """Lấy tất cả file giọng nói của user"""
        if not self.user_exists(user_id):
            return []
        return self.users[user_id]['voice_samples_files']
    
    def delete_user(self, user_id):
        """Xóa user"""
        if not self.user_exists(user_id):
            return False, "User không tồn tại!"
        
        # Xóa các file dữ liệu
        user_data = self.users[user_id]
        for face_file in user_data['face_embeddings']:
            try:
                os.remove(face_file)
            except:
                pass
        
        for voice_file in user_data['voice_samples_files']:
            try:
                os.remove(voice_file)
            except:
                pass
        
        # Xóa khỏi database
        del self.users[user_id]
        success = self._save_users()
        
        if success:
            return True, f"Đã xóa user '{user_id}'"
        else:
            return False, "Lỗi khi xóa user"
    
    def _get_timestamp(self):
        """Lấy timestamp hiện tại"""
        return datetime.now().isoformat()
    
    def backup_database(self, backup_dir="backups"):
        """Sao lưu database"""
        try:
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = os.path.join(backup_dir, f"users_backup_{timestamp}.json")
            
            with open(backup_file, 'w', encoding='utf-8') as f:
                json.dump(self.users, f, ensure_ascii=False, indent=2)
            
            return True, f"Đã sao lưu thành công: {backup_file}"
        except Exception as e:
            return False, f"Lỗi sao lưu: {e}"
    
    def refresh_data(self):
        """Làm mới dữ liệu từ file"""
        self.users = self._load_users()
        return True