import pyaudio
import wave
import numpy as np
import threading
import time
from config import Config

class AudioRecorder:
    def __init__(self):
        self.audio = pyaudio.PyAudio()
        self.is_recording = False
        self.frames = []
        self.stream = None
    
    def start_recording(self, duration=Config.VOICE_SAMPLE_DURATION):
        """Bắt đầu ghi âm"""
        try:
            self.is_recording = True
            self.frames = []
            
            self.stream = self.audio.open(
                format=pyaudio.paInt16,
                channels=1,
                rate=16000,
                input=True,
                frames_per_buffer=1024
            )
            
            recording_thread = threading.Thread(target=self._record, args=(duration,))
            recording_thread.daemon = True
            recording_thread.start()
            
            return True
        except Exception as e:
            print(f"❌ Lỗi khởi động ghi âm: {e}")
            return False
    
    def _record(self, duration):
        """Thread ghi âm"""
        start_time = time.time()
        
        while self.is_recording and (time.time() - start_time) < duration:
            try:
                data = self.stream.read(1024, exception_on_overflow=False)
                self.frames.append(data)
            except Exception as e:
                print(f"Lỗi ghi âm: {e}")
                break
        
        self.stop_recording()
    
    def stop_recording(self):
        """Dừng ghi âm"""
        self.is_recording = False
        if self.stream:
            self.stream.stop_stream()
            self.stream.close()
    
    def get_audio_data(self):
        """Lấy dữ liệu audio đã ghi"""
        if not self.frames:
            return None
        
        audio_data = b''.join(self.frames)
        audio_array = np.frombuffer(audio_data, dtype=np.int16)
        
        return audio_array
    
    def save_to_wav(self, filename):
        """Lưu audio thành file WAV"""
        if not self.frames:
            return False
        
        try:
            wf = wave.open(filename, 'wb')
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(16000)
            wf.writeframes(b''.join(self.frames))
            wf.close()
            return True
        except Exception as e:
            print(f"❌ Lỗi lưu file WAV: {e}")
            return False
    
    def cleanup(self):
        """Dọn dẹp tài nguyên"""
        if self.stream:
            self.stream.close()
        self.audio.terminate()

class AudioPlayer:
    def __init__(self):
        self.audio = pyaudio.PyAudio()
    
    def play_wav(self, filename):
        """Phát file WAV"""
        try:
            wf = wave.open(filename, 'rb')
            
            stream = self.audio.open(
                format=self.audio.get_format_from_width(wf.getsampwidth()),
                channels=wf.getnchannels(),
                rate=wf.getframerate(),
                output=True
            )
            
            data = wf.readframes(1024)
            while data:
                stream.write(data)
                data = wf.readframes(1024)
            
            stream.stop_stream()
            stream.close()
            wf.close()
            return True
        except Exception as e:
            print(f"❌ Lỗi phát audio: {e}")
            return False
    
    def cleanup(self):
        """Dọn dẹp tài nguyên"""
        self.audio.terminate()