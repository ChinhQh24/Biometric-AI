import cv2
import threading
import time
from config import Config

class CameraManager:
    def __init__(self):
        self.cap = None
        self.camera_running = False
        self.current_frame = None
        self.frame_callbacks = []
    
    def start_camera(self) -> bool:
        """Khởi động camera"""
        try:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                self.cap = cv2.VideoCapture(1)
                if not self.cap.isOpened():
                    return False
            
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, Config.CAMERA_WIDTH)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, Config.CAMERA_HEIGHT)
            
            self.camera_running = True
            self._start_frame_loop()
            return True
        except Exception as e:
            print(f"❌ Lỗi khởi động camera: {e}")
            return False
    
    def stop_camera(self):
        """Dừng camera"""
        self.camera_running = False
        if self.cap:
            self.cap.release()
            self.cap = None
        self.current_frame = None
    
    def _start_frame_loop(self):
        """Vòng lặp lấy frame từ camera"""
        def frame_loop():
            while self.camera_running and self.cap and self.cap.isOpened():
                ret, frame = self.cap.read()
                if ret:
                    self.current_frame = frame
                    for callback in self.frame_callbacks:
                        try:
                            callback(frame)
                        except Exception as e:
                            print(f"Lỗi callback: {e}")
                time.sleep(0.03)
        
        thread = threading.Thread(target=frame_loop, daemon=True)
        thread.start()
    
    def add_frame_callback(self, callback):
        """Thêm callback khi có frame mới"""
        self.frame_callbacks.append(callback)
    
    def get_current_frame(self):
        """Lấy frame hiện tại"""
        return self.current_frame