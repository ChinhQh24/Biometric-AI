import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import cv2
from PIL import Image, ImageTk
import threading
import time
import os

from config import Config
from services.registration_service import RegistrationService
from services.auth_service import AuthService
from utils.camera import CameraManager

class BiometricAuthenticationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Biometric Authentication System")
        self.root.geometry("1000x750")
        
        # Khởi tạo services
        self.camera_manager = CameraManager()
        self.registration_service = RegistrationService()
        self.auth_service = AuthService()
        
        # Đăng ký callback để nhận thông báo khi dữ liệu thay đổi
        self.registration_service.database.on_data_changed = self.on_database_changed
        
        # Biến giao diện
        self.current_user_id = tk.StringVar()
        self.full_name = tk.StringVar()
        self.selected_user_id = tk.StringVar()
        self.app_mode = tk.StringVar(value="registration")  # registration, authentication
        self.auth_mode = tk.StringVar(value="face")
        self.status_var = tk.StringVar(value="Sẵn sàng")
        
        # Biến để theo dõi số lượng user
        self._last_user_count = 0
        self._last_auth_user_count = 0
        
        self.setup_ui()
        self.setup_event_handlers()
        
        # Tạo thư mục data nếu chưa tồn tại
        os.makedirs(Config.DATA_DIR, exist_ok=True)
        
        # Load danh sách users ban đầu
        self.refresh_users_list()
    
    def setup_ui(self):
        """Thiết lập giao diện người dùng"""
        # Main container
        main_container = ttk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # ===== HEADER - CHỌN CHẾ ĐỘ =====
        header_frame = ttk.Frame(main_container)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(header_frame, text="HỆ THỐNG XÁC THỰC SINH TRẮC HỌC AI", 
                 font=('Arial', 14, 'bold')).pack(side=tk.LEFT)
        
        mode_frame = ttk.Frame(header_frame)
        mode_frame.pack(side=tk.RIGHT)
        
        ttk.Radiobutton(mode_frame, text="📝 Đăng ký", 
                       variable=self.app_mode, value="registration",
                       command=self.on_mode_changed).pack(side=tk.LEFT, padx=5)
        ttk.Radiobutton(mode_frame, text="🔐 Xác thực", 
                       variable=self.app_mode, value="authentication",
                       command=self.on_mode_changed).pack(side=tk.LEFT, padx=5)
        
        # ===== MAIN CONTENT =====
        content_frame = ttk.Frame(main_container)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # ===== LEFT PANEL - CAMERA =====
        self.left_panel = ttk.LabelFrame(content_frame, text="Camera", padding=10)
        self.left_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        # Camera display
        self.camera_label = ttk.Label(self.left_panel, background='black', relief='sunken')
        self.camera_label.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Camera controls
        cam_controls = ttk.Frame(self.left_panel)
        cam_controls.pack(fill=tk.X, pady=5)
        
        ttk.Button(cam_controls, text="📷 Bật Camera", 
                  command=self.start_camera).pack(side=tk.LEFT, padx=5)
        ttk.Button(cam_controls, text="⏹️ Dừng Camera", 
                  command=self.stop_camera).pack(side=tk.LEFT, padx=5)
        
        # ===== RIGHT PANEL - ĐĂNG KÝ (mặc định) =====
        self.setup_registration_panel(content_frame)
        self.setup_authentication_panel(content_frame)
        
        # ===== STATUS BAR =====
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief='sunken')
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Hiển thị panel mặc định
        self.on_mode_changed()
    
    def setup_registration_panel(self, parent):
        """Thiết lập panel đăng ký"""
        self.registration_panel = ttk.Frame(parent)
        
        # User info frame
        user_frame = ttk.LabelFrame(self.registration_panel, text="Thông tin User", padding=10)
        user_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(user_frame, text="User ID*:").grid(row=0, column=0, sticky='w', pady=2)
        ttk.Entry(user_frame, textvariable=self.current_user_id, width=20).grid(row=0, column=1, pady=2, padx=5, sticky='we')
        
        ttk.Label(user_frame, text="Họ tên:").grid(row=1, column=0, sticky='w', pady=2)
        ttk.Entry(user_frame, textvariable=self.full_name, width=20).grid(row=1, column=1, pady=2, padx=5, sticky='we')
        
        user_frame.columnconfigure(1, weight=1)
        
        # Registration buttons
        reg_buttons = ttk.Frame(self.registration_panel)
        reg_buttons.pack(fill=tk.X, pady=5)
        
        ttk.Button(reg_buttons, text="👤 Tạo User Mới", 
                  command=self.create_new_user, style='Accent.TButton').pack(fill=tk.X, pady=2)
        ttk.Button(reg_buttons, text="📸 Đăng ký Khuôn mặt", 
                  command=self.register_face).pack(fill=tk.X, pady=2)
        ttk.Button(reg_buttons, text="🎤 Đăng ký Giọng nói", 
                  command=self.register_voice).pack(fill=tk.X, pady=2)
        
        # Registration status
        status_frame = ttk.LabelFrame(self.registration_panel, text="Trạng thái Đăng ký", padding=10)
        status_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.reg_status_text = scrolledtext.ScrolledText(status_frame, height=8)
        self.reg_status_text.pack(fill=tk.BOTH, expand=True)
        
        # Progress frames
        progress_frame = ttk.Frame(status_frame)
        progress_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(progress_frame, text="Khuôn mặt:").grid(row=0, column=0, sticky='w')
        self.face_progress = ttk.Progressbar(progress_frame, orient='horizontal', length=150, mode='determinate')
        self.face_progress.grid(row=0, column=1, padx=5, sticky='we')
        self.face_label = ttk.Label(progress_frame, text="0/3")
        self.face_label.grid(row=0, column=2, padx=5)
        
        ttk.Label(progress_frame, text="Giọng nói:").grid(row=1, column=0, sticky='w', pady=2)
        self.voice_progress = ttk.Progressbar(progress_frame, orient='horizontal', length=150, mode='determinate')
        self.voice_progress.grid(row=1, column=1, padx=5, pady=2, sticky='we')
        self.voice_label = ttk.Label(progress_frame, text="0/2")
        self.voice_label.grid(row=1, column=2, padx=5, pady=2)
        
        progress_frame.columnconfigure(1, weight=1)
        
        # Users list
        users_frame = ttk.LabelFrame(self.registration_panel, text="Danh sách Users", padding=10)
        users_frame.pack(fill=tk.BOTH, expand=True)
        
        listbox_frame = ttk.Frame(users_frame)
        listbox_frame.pack(fill=tk.BOTH, expand=True)
        
        self.users_listbox = tk.Listbox(listbox_frame)
        scrollbar = ttk.Scrollbar(listbox_frame, orient='vertical', command=self.users_listbox.yview)
        self.users_listbox.configure(yscrollcommand=scrollbar.set)
        
        self.users_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # User list controls
        list_controls = ttk.Frame(users_frame)
        list_controls.pack(fill=tk.X, pady=5)
        
        ttk.Button(list_controls, text="🔄 Làm mới", 
                  command=self.refresh_users_list).pack(side=tk.LEFT, padx=2)
        ttk.Button(list_controls, text="📊 Xem trạng thái", 
                  command=self.show_user_status).pack(side=tk.LEFT, padx=2)
        ttk.Button(list_controls, text="🗑️ Xóa User", 
                  command=self.delete_user).pack(side=tk.LEFT, padx=2)
    
    def setup_authentication_panel(self, parent):
        """Thiết lập panel xác thực"""
        self.authentication_panel = ttk.Frame(parent)
        
        # Authentication mode selection
        mode_frame = ttk.LabelFrame(self.authentication_panel, text="Chế độ Xác thực", padding=10)
        mode_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Radiobutton(mode_frame, text="Xác thực Khuôn mặt", 
                       variable=self.auth_mode, value="face").pack(anchor='w')
        ttk.Radiobutton(mode_frame, text="Xác thực Giọng nói", 
                       variable=self.auth_mode, value="voice").pack(anchor='w')
        ttk.Radiobutton(mode_frame, text="Xác thực Đa yếu tố", 
                       variable=self.auth_mode, value="multi").pack(anchor='w')
        ttk.Radiobutton(mode_frame, text="Nhận diện Tự động", 
                       variable=self.auth_mode, value="identify").pack(anchor='w')
        
        # User selection
        user_frame = ttk.LabelFrame(self.authentication_panel, text="Chọn User", padding=10)
        user_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.user_combobox = ttk.Combobox(user_frame, textvariable=self.selected_user_id, state="readonly")
        self.user_combobox.pack(fill=tk.X, pady=2)
        
        ttk.Button(user_frame, text="🔄 Làm mới DS User", 
                  command=self.refresh_auth_users_list).pack(fill=tk.X, pady=2)
        
        # Authentication buttons
        auth_buttons = ttk.Frame(self.authentication_panel)
        auth_buttons.pack(fill=tk.X, pady=5)
        
        ttk.Button(auth_buttons, text="🔐 Bắt đầu Xác thực", 
                  command=self.start_authentication, style='Success.TButton').pack(fill=tk.X, pady=2)
        
        # Result display
        result_frame = ttk.LabelFrame(self.authentication_panel, text="Kết quả Xác thực", padding=10)
        result_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        self.result_text = scrolledtext.ScrolledText(result_frame, height=10)
        self.result_text.pack(fill=tk.BOTH, expand=True)
        
        # Confidence indicator
        confidence_frame = ttk.Frame(result_frame)
        confidence_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(confidence_frame, text="Độ tin cậy:").pack(side=tk.LEFT)
        self.confidence_bar = ttk.Progressbar(confidence_frame, orient='horizontal', 
                                             length=200, mode='determinate')
        self.confidence_bar.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        self.confidence_label = ttk.Label(confidence_frame, text="0%")
        self.confidence_label.pack(side=tk.RIGHT)
        
        # Statistics
        stats_frame = ttk.LabelFrame(self.authentication_panel, text="Thống kê Hệ thống", padding=10)
        stats_frame.pack(fill=tk.X)
        
        self.stats_text = tk.Text(stats_frame, height=4)
        self.stats_text.pack(fill=tk.BOTH, expand=True)
        
        # Tạo styles
        style = ttk.Style()
        style.configure('Accent.TButton', foreground='black', background='#0078D7')
        style.configure('Success.TButton', foreground='black', background='#28a745')
    
    def setup_event_handlers(self):
        """Thiết lập event handlers"""
        self.camera_manager.add_frame_callback(self.on_new_frame)
        self.users_listbox.bind('<<ListboxSelect>>', self.on_user_selected)
    
    def on_mode_changed(self):
        """Xử lý khi thay đổi chế độ"""
        if self.app_mode.get() == "registration":
            self.authentication_panel.pack_forget()
            self.registration_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
            self.left_panel.configure(text="Camera - Đăng ký")
            self.refresh_users_list()
        else:
            self.registration_panel.pack_forget()
            self.authentication_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
            self.left_panel.configure(text="Camera - Xác thực")
            self.refresh_auth_users_list()
            self.update_statistics()
    
    def on_new_frame(self, frame):
        """Xử lý khi có frame mới từ camera"""
        self.root.after(0, lambda: self.update_camera_display(frame))
    
    def update_camera_display(self, frame):
        """Cập nhật hiển thị camera"""
        try:
            frame = cv2.resize(frame, (400, 300))
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame_rgb)
            imgtk = ImageTk.PhotoImage(image=img)
            
            self.camera_label.imgtk = imgtk
            self.camera_label.configure(image=imgtk)
        except Exception as e:
            self.log_message(f"❌ Lỗi hiển thị camera: {e}")
    
    def on_user_selected(self, event):
        """Xử lý khi user được chọn từ listbox"""
        selection = self.users_listbox.curselection()
        if selection:
            user_id = self.users_listbox.get(selection[0])
            self.current_user_id.set(user_id)
            self.update_user_status_display(user_id)
    
    # ===== REGISTRATION METHODS =====
    def start_camera(self):
        """Bật camera"""
        if self.camera_manager.start_camera():
            self.log_message("✅ Camera đã bật")
        else:
            self.log_message("❌ Không thể bật camera")
            messagebox.showerror("Lỗi", "Không thể kết nối camera!")
    
    def stop_camera(self):
        """Dừng camera"""
        self.camera_manager.stop_camera()
        self.log_message("⏹️ Camera đã dừng")
    
    def create_new_user(self):
        """Tạo user mới"""
        user_id = self.current_user_id.get().strip()
        if not user_id:
            messagebox.showerror("Lỗi", "Vui lòng nhập User ID!")
            return
        
        user_info = {'full_name': self.full_name.get().strip()}
        
        success, message = self.registration_service.register_new_user(user_id, user_info)
        if success:
            self.log_message(f"✅ {message}")
            messagebox.showinfo("Thành công", message)
            self.refresh_users_list()
            self.update_user_status_display(user_id)
        else:
            self.log_message(f"❌ {message}")
            messagebox.showerror("Lỗi", message)
    
    def register_face(self):
        """Đăng ký khuôn mặt"""
        user_id = self.current_user_id.get().strip()
        if not user_id:
            messagebox.showerror("Lỗi", "Vui lòng chọn User ID!")
            return
        
        if self.camera_manager.current_frame is None:
            messagebox.showerror("Lỗi", "Vui lòng bật camera trước!")
            return
        
        if not self.registration_service.database.user_exists(user_id):
            messagebox.showerror("Lỗi", "User không tồn tại! Hãy tạo user trước.")
            return
        
        self.log_message(f"📸 Đang đăng ký khuôn mặt cho {user_id}...")
        self.status_var.set("Đang xử lý khuôn mặt...")
        
        threading.Thread(target=self._register_face_thread, args=(user_id,), daemon=True).start()
    
    def _register_face_thread(self, user_id):
        """Thread đăng ký khuôn mặt"""
        success, message = self.registration_service.register_face_sample(user_id, self.camera_manager.current_frame)
        self.root.after(0, lambda: self._handle_registration_result(success, message, user_id))
    
    def register_voice(self):
        """Đăng ký giọng nói"""
        user_id = self.current_user_id.get().strip()
        if not user_id:
            messagebox.showerror("Lỗi", "Vui lòng chọn User ID!")
            return
        
        if not self.registration_service.database.user_exists(user_id):
            messagebox.showerror("Lỗi", "User không tồn tại! Hãy tạo user trước.")
            return
        
        self.log_message(f"🎤 Đang ghi âm cho {user_id}... Hãy nói '{Config.VOICE_PASSPHRASE}'")
        self.status_var.set("Đang ghi âm...")
        
        threading.Thread(target=self._register_voice_thread, args=(user_id,), daemon=True).start()
    
    def _register_voice_thread(self, user_id):
        """Thread đăng ký giọng nói"""
        success, message = self.registration_service.register_voice_sample(user_id)
        self.root.after(0, lambda: self._handle_registration_result(success, message, user_id))
    
    def _handle_registration_result(self, success, message, user_id):
        """Xử lý kết quả đăng ký"""
        self.status_var.set("Sẵn sàng")
        
        if success:
            self.log_message(f"✅ {message}")
            messagebox.showinfo("Thành công", message)
            self.update_user_status_display(user_id)
        else:
            self.log_message(f"❌ {message}")
            messagebox.showerror("Lỗi", message)
    
    def refresh_users_list(self):
        """Làm mới danh sách users"""
        self.users_listbox.delete(0, tk.END)
        users = self.registration_service.get_all_users()
        
        for user_id in users:
            self.users_listbox.insert(tk.END, user_id)
        
        self.log_message(f"📋 Đã tải {len(users)} users")
    
    def show_user_status(self):
        """Hiển thị trạng thái user được chọn"""
        selection = self.users_listbox.curselection()
        if not selection:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn một user từ danh sách!")
            return
        
        user_id = self.users_listbox.get(selection[0])
        self.update_user_status_display(user_id)
    
    def update_user_status_display(self, user_id):
        """Cập nhật hiển thị trạng thái user"""
        status = self.registration_service.get_user_registration_status(user_id)
        if not status:
            return
        
        # Clear status text
        self.reg_status_text.delete(1.0, tk.END)
        
        # Hiển thị thông tin chi tiết
        status_info = f"User ID: {status['user_id']}\n"
        status_info += f"Khuôn mặt: {status['face_samples']}/{Config.FACE_SAMPLES_REQUIRED} mẫu\n"
        status_info += f"Giọng nói: {status['voice_samples']}/{Config.VOICE_SAMPLES_REQUIRED} mẫu\n"
        status_info += f"Trạng thái: {'✅ ĐÃ HOÀN THÀNH' if status['fully_registered'] else '🟡 CHƯA HOÀN THÀNH'}\n"
        status_info += f"Ngày tạo: {status['created_at']}\n"
        
        if status['last_face_update']:
            status_info += f"Cập nhật khuôn mặt: {status['last_face_update']}\n"
        if status['last_voice_update']:
            status_info += f"Cập nhật giọng nói: {status['last_voice_update']}\n"
        
        self.reg_status_text.insert(tk.END, status_info)
        
        # Cập nhật progress bars
        face_progress = (status['face_samples'] / Config.FACE_SAMPLES_REQUIRED) * 100
        voice_progress = (status['voice_samples'] / Config.VOICE_SAMPLES_REQUIRED) * 100
        
        self.face_progress['value'] = face_progress
        self.voice_progress['value'] = voice_progress
        
        self.face_label.config(text=f"{status['face_samples']}/{Config.FACE_SAMPLES_REQUIRED}")
        self.voice_label.config(text=f"{status['voice_samples']}/{Config.VOICE_SAMPLES_REQUIRED}")
    
    def delete_user(self):
        """Xóa user được chọn"""
        selection = self.users_listbox.curselection()
        if not selection:
            messagebox.showwarning("Cảnh báo", "Vui lòng chọn một user từ danh sách!")
            return
        
        user_id = self.users_listbox.get(selection[0])
        
        confirm = messagebox.askyesno("Xác nhận", f"Bạn có chắc muốn xóa user '{user_id}'?")
        if not confirm:
            return
        
        success, message = self.registration_service.database.delete_user(user_id)
        if success:
            self.log_message(f"✅ {message}")
            messagebox.showinfo("Thành công", message)
            self.refresh_users_list()
            self.reg_status_text.delete(1.0, tk.END)
            self.face_progress['value'] = 0
            self.voice_progress['value'] = 0
            self.face_label.config(text="0/3")
            self.voice_label.config(text="0/2")
        else:
            self.log_message(f"❌ {message}")
            messagebox.showerror("Lỗi", message)
    
    # ===== AUTHENTICATION METHODS =====
    def refresh_auth_users_list(self):
        """Làm mới danh sách users có thể xác thực"""
        available_users = self.auth_service.get_available_users()
        self.user_combobox['values'] = available_users
        
        if available_users:
            self.selected_user_id.set(available_users[0])
            self.log_message(f"📋 Đã tải {len(available_users)} users có thể xác thực")
        else:
            self.log_message("⚠️ Không có user nào có dữ liệu xác thực")
    
    def start_authentication(self):
        """Bắt đầu quá trình xác thực"""
        mode = self.auth_mode.get()
        
        if mode in ["face", "voice", "multi"]:
            user_id = self.selected_user_id.get()
            if not user_id:
                messagebox.showerror("Lỗi", "Vui lòng chọn một user!")
                return
            
            if mode == "face":
                self.authenticate_face(user_id)
            elif mode == "voice":
                self.authenticate_voice(user_id)
            elif mode == "multi":
                self.authenticate_multi_factor(user_id)
        
        elif mode == "identify":
            self.identify_user()
    
    def authenticate_face(self, user_id):
        """Xác thực khuôn mặt"""
        if self.camera_manager.current_frame is None:
            messagebox.showerror("Lỗi", "Vui lòng bật camera trước!")
            return
        
        self.log_message(f"🔍 Đang xác thực khuôn mặt cho {user_id}...")
        self.status_var.set("Đang xác thực khuôn mặt...")
        
        threading.Thread(target=self._authenticate_face_thread, 
                        args=(user_id,), daemon=True).start()
    
    def _authenticate_face_thread(self, user_id):
        """Thread xác thực khuôn mặt"""
        success, confidence, message = self.auth_service.verify_user_face(
            self.camera_manager.current_frame, user_id
        )
        
        self.root.after(0, lambda: self._handle_auth_result(
            success, message, confidence, "FACE"
        ))
    
    def authenticate_voice(self, user_id):
        """Xác thực giọng nói"""
        self.log_message(f"🎤 Đang xác thực giọng nói cho {user_id}...")
        self.log_message(f"🗣️ Hãy nói: '{Config.VOICE_PASSPHRASE}'")
        self.status_var.set("Đang ghi âm...")
        
        threading.Thread(target=self._authenticate_voice_thread, 
                        args=(user_id,), daemon=True).start()
    
    def _authenticate_voice_thread(self, user_id):
        """Thread xác thực giọng nói"""
        success, message = self.auth_service.verify_user_voice(user_id)
        
        self.root.after(0, lambda: self._handle_auth_result(
            success, message, 1.0 if success else 0.0, "VOICE"
        ))
    
    def authenticate_multi_factor(self, user_id):
        """Xác thực đa yếu tố"""
        if self.camera_manager.current_frame is None:
            messagebox.showerror("Lỗi", "Vui lòng bật camera trước!")
            return
        
        self.log_message(f"🔐 Đang xác thực đa yếu tố cho {user_id}...")
        self.log_message(f"🗣️ Hãy nói: '{Config.VOICE_PASSPHRASE}'")
        self.status_var.set("Đang xác thực đa yếu tố...")
        
        threading.Thread(target=self._authenticate_multi_factor_thread, 
                        args=(user_id,), daemon=True).start()
    
    def _authenticate_multi_factor_thread(self, user_id):
        """Thread xác thực đa yếu tố"""
        success, message = self.auth_service.multi_factor_auth(
            self.camera_manager.current_frame, user_id
        )
        
        self.root.after(0, lambda: self._handle_auth_result(
            success, message, 1.0 if success else 0.0, "MULTI_FACTOR"
        ))
    
    def identify_user(self):
        """Nhận diện user tự động"""
        if self.camera_manager.current_frame is None:
            messagebox.showerror("Lỗi", "Vui lòng bật camera trước!")
            return
        
        self.log_message("🔍 Đang nhận diện user tự động...")
        self.status_var.set("Đang nhận diện...")
        
        threading.Thread(target=self._identify_user_thread, daemon=True).start()
    
    def _identify_user_thread(self):
        """Thread nhận diện user"""
        user_id, confidence, message = self.auth_service.identify_face(
            self.camera_manager.current_frame
        )
        
        success = user_id is not None
        self.root.after(0, lambda: self._handle_auth_result(
            success, message, confidence, "IDENTIFY"
        ))
    
    def _handle_auth_result(self, success, message, confidence, auth_type):
        """Xử lý kết quả xác thực"""
        self.status_var.set("Sẵn sàng")
        
        # Hiển thị kết quả
        self.result_text.delete(1.0, tk.END)
        
        timestamp = time.strftime("%H:%M:%S")
        result_content = f"[{timestamp}] {message}\n\n"
        
        if success:
            result_content += "✅ XÁC THỰC THÀNH CÔNG!\n"
            result_content += f"🔐 Loại xác thực: {auth_type}\n"
            if confidence > 0:
                result_content += f"📊 Độ tin cậy: {confidence:.2f}\n"
            
            confidence_percent = int(confidence * 100)
            self.confidence_bar['value'] = confidence_percent
            self.confidence_label.config(text=f"{confidence_percent}%")
            
            self.log_message(f"✅ Xác thực thành công: {message}")
        else:
            result_content += "❌ XÁC THỰC THẤT BẠI!\n"
            result_content += f"🔐 Loại xác thực: {auth_type}\n"
            
            self.confidence_bar['value'] = 0
            self.confidence_label.config(text="0%")
            
            self.log_message(f"❌ Xác thực thất bại: {message}")
        
        self.result_text.insert(tk.END, result_content)
        self.update_statistics()
    
    def update_statistics(self):
        """Cập nhật thống kê"""
        available_users = self.auth_service.get_available_users()
        total_users = len(available_users)
        
        users_with_face = 0
        users_with_voice = 0
        
        for user_id in available_users:
            auth_status = self.auth_service.get_user_auth_status(user_id)
            if auth_status['has_face_data']:
                users_with_face += 1
            if auth_status['has_voice_data']:
                users_with_voice += 1
        
        stats_text = f"Tổng số users: {total_users}\n"
        stats_text += f"Có dữ liệu khuôn mặt: {users_with_face}\n"
        stats_text += f"Có dữ liệu giọng nói: {users_with_voice}\n"
        stats_text += f"Có thể xác thực: {total_users}"
        
        self.stats_text.delete(1.0, tk.END)
        self.stats_text.insert(tk.END, stats_text)
    
    def log_message(self, message):
        """Ghi log"""
        timestamp = time.strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {message}\n"
        print(log_entry.strip())
    
    def on_closing(self):
        """Xử lý khi đóng ứng dụng"""
        self.camera_manager.stop_camera()
        self.root.destroy()

def main():
    root = tk.Tk()
    app = BiometricAuthenticationApp(root)
    
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()