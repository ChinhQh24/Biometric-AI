import numpy as np
import os
from config import Config
from models.face_encoder import FaceEncoder

class FaceVerifier:
    def __init__(self):
        self.face_encoder = FaceEncoder()
        self.verification_threshold = 0.5
    
    def verify_face(self, image, user_id):
        """Xác thực khuôn mặt với user cụ thể"""
        current_embedding = self.face_encoder.extract_face_embedding(image)
        if current_embedding is None:
            return False, 0, "Không tìm thấy khuôn mặt!"
        
        registered_embeddings = self._load_user_embeddings(user_id)
        if not registered_embeddings:
            return False, 0, f"User {user_id} chưa đăng ký khuôn mặt!"
        
        max_similarity = 0
        for registered_embedding in registered_embeddings:
            similarity = self._cosine_similarity(current_embedding, registered_embedding)
            max_similarity = max(max_similarity, similarity)
        
        is_verified = max_similarity >= self.verification_threshold
        
        if is_verified:
            return True, max_similarity, f"Xác thực thành công! Độ tin cậy: {max_similarity:.2f}"
        else:
            return False, max_similarity, f"Xác thực thất bại! Độ tin cậy: {max_similarity:.2f}"
    
    def identify_face(self, image):
        """Nhận diện khuôn mặt từ tất cả users"""
        current_embedding = self.face_encoder.extract_face_embedding(image)
        if current_embedding is None:
            return None, 0, "Không tìm thấy khuôn mặt!"
        
        from utils.database import UserDatabase
        db = UserDatabase()
        all_users = db.get_all_users()
        
        best_match = None
        best_similarity = 0
        
        for user_id in all_users:
            user_embeddings = self._load_user_embeddings(user_id)
            if not user_embeddings:
                continue
            
            for registered_embedding in user_embeddings:
                similarity = self._cosine_similarity(current_embedding, registered_embedding)
                if similarity > best_similarity and similarity >= self.verification_threshold:
                    best_similarity = similarity
                    best_match = user_id
        
        if best_match:
            return best_match, best_similarity, f"Nhận diện: {best_match} (độ tin cậy: {best_similarity:.2f})"
        else:
            return None, 0, "Không nhận diện được user nào!"
    
    def _load_user_embeddings(self, user_id):
        """Load tất cả embeddings của user"""
        from utils.database import UserDatabase
        db = UserDatabase()
        user_info = db.get_user_info(user_id)
        
        if not user_info:
            return []
        
        embeddings = []
        for embedding_file in user_info.get('face_embeddings', []):
            try:
                if os.path.exists(embedding_file):
                    embedding = np.load(embedding_file)
                    embeddings.append(embedding)
            except Exception as e:
                print(f"❌ Lỗi đọc embedding file {embedding_file}: {e}")
        
        return embeddings
    
    def _cosine_similarity(self, embedding1, embedding2):
        """Tính cosine similarity"""
        return np.dot(embedding1, embedding2) / (np.linalg.norm(embedding1) * np.linalg.norm(embedding2))