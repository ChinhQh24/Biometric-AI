import speech_recognition as sr
from config import Config

class VoiceVerifier:
    def __init__(self):
        self.recognizer = sr.Recognizer()
    
    def verify_voice(self, user_id):
        """Xác thực giọng nói với user cụ thể"""
        audio, success = self._record_voice_sample()
        if not success:
            return False, "Lỗi ghi âm!"
        
        try:
            current_text = self.recognizer.recognize_google(audio, language="vi-VN")
            print(f"📝 Nhận diện: {current_text}")
        except sr.UnknownValueError:
            return False, "Không nhận diện được giọng nói!"
        except sr.RequestError as e:
            return False, f"Lỗi dịch vụ nhận diện: {e}"
        
        if Config.VOICE_PASSPHRASE.lower() not in current_text.lower():
            return False, f"Sai câu mật khẩu! Hãy nói '{Config.VOICE_PASSPHRASE}'"
        
        from utils.database import UserDatabase
        db = UserDatabase()
        user_info = db.get_user_info(user_id)
        
        if not user_info or user_info['voice_samples'] == 0:
            return False, f"User {user_id} chưa đăng ký giọng nói!"
        
        return True, "Xác thực giọng nói thành công!"
    
    def identify_voice(self):
        """Nhận diện giọng nói từ tất cả users"""
        audio, success = self._record_voice_sample()
        if not success:
            return None, "Lỗi ghi âm!"
        
        try:
            current_text = self.recognizer.recognize_google(audio, language="vi-VN")
            print(f"📝 Nhận diện: {current_text}")
        except sr.UnknownValueError:
            return None, "Không nhận diện được giọng nói!"
        except sr.RequestError as e:
            return None, f"Lỗi dịch vụ nhận diện: {e}"
        
        if Config.VOICE_PASSPHRASE.lower() not in current_text.lower():
            return None, f"Sai câu mật khẩu! Hãy nói '{Config.VOICE_PASSPHRASE}'"
        
        return "verified", "Nhận diện giọng nói thành công!"
    
    def _record_voice_sample(self, duration=None):
        """Ghi âm mẫu giọng nói"""
        if duration is None:
            duration = Config.VOICE_SAMPLE_DURATION
            
        try:
            with sr.Microphone() as source:
                print("🎤 Đang ghi âm xác thực...")
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
                audio = self.recognizer.record(source, duration=duration)
                return audio, True
        except Exception as e:
            print(f"❌ Lỗi ghi âm: {e}")
            return None, False