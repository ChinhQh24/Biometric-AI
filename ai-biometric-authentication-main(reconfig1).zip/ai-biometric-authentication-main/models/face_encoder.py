import insightface
import cv2
import numpy as np
import os
from config import Config

class FaceEncoder:
    def __init__(self):
        self.model = None
        self.load_model()
    
    def load_model(self):
        """Tải model nhận diện khuôn mặt"""
        try:
            self.model = insightface.app.FaceAnalysis(name=Config.FACE_MODEL_NAME)
            self.model.prepare(ctx_id=0, det_size=(640, 640))
            print("✅ Face model loaded successfully")
        except Exception as e:
            print(f"❌ Error loading face model: {e}")
    
    def extract_face_embedding(self, image):
        """Trích xuất embedding từ khuôn mặt trong ảnh"""
        faces = self.model.get(image)
        if len(faces) == 1:
            return faces[0].embedding
        return None
    
    def save_face_embedding(self, user_id, embedding, sample_index):
        """Lưu embedding vào file"""
        os.makedirs(Config.FACES_DIR, exist_ok=True)
        filename = f"{Config.FACES_DIR}/{user_id}_face_{sample_index}.npy"
        np.save(filename, embedding)
        return filename
    
    def validate_face_sample(self, image):
        """Kiểm tra ảnh có hợp lệ để đăng ký không"""
        faces = self.model.get(image)
        if len(faces) == 0:
            return False, "Không phát hiện khuôn mặt!"
        elif len(faces) > 1:
            return False, "Vui lòng chỉ có một khuôn mặt trong khung hình!"
        else:
            face = faces[0]
            if face.det_score < Config.FACE_DETECTION_CONFIDENCE:
                return False, "Khuôn mặt không rõ ràng. Vui lòng thử lại!"
            return True, "Khuôn mặt hợp lệ"