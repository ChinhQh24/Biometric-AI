import speech_recognition as sr
import numpy as np
import os
import wave
from config import Config

class VoiceEncoder:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        # Giảm ngưỡng năng lượng để dễ nhận diện hơn
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True
    
    def record_voice_sample(self, duration=None):
        """Ghi âm mẫu giọng nói - Phiên bản cải tiến"""
        if duration is None:
            duration = Config.VOICE_SAMPLE_DURATION
            
        try:
            with sr.Microphone() as source:
                print("🎤 Đang điều chỉnh tiếng ồn nền...")
                # Điều chỉnh tiếng ồn lâu hơn
                self.recognizer.adjust_for_ambient_noise(source, duration=2)
                
                print("🎤 Bắt đầu ghi âm... Hãy nói ngay bây giờ!")
                audio = self.recognizer.listen(source, timeout=10, phrase_time_limit=duration)
                return audio, True
                
        except sr.WaitTimeoutError:
            return None, False, "⏰ Hết thời gian chờ! Vui lòng thử lại."
        except Exception as e:
            print(f"❌ Lỗi ghi âm: {e}")
            return None, False, f"Lỗi micro: {e}"
    
    def validate_voice_sample(self, audio):
        """Kiểm tra mẫu giọng nói có hợp lệ không - Phiên bản cải tiến"""
        try:
            print("🔊 Đang nhận diện giọng nói...")
            # Thử với nhiều ngôn ngữ và cấu hình
            text = self.recognizer.recognize_google(audio, language="vi-VN")
            print(f"📝 Nhận diện được: '{text}'")
            
            # Kiểm tra linh hoạt hơn
            spoken_text = text.lower()
            expected_phrase = Config.VOICE_PASSPHRASE.lower()
            
            # Cho phép sai khác nhỏ
            if expected_phrase in spoken_text:
                return True, "Mẫu giọng nói hợp lệ!", text
            else:
                return False, f"Không khớp! Bạn nói: '{text}'. Hãy nói: '{Config.VOICE_PASSPHRASE}'", text
                
        except sr.UnknownValueError:
            print("❌ Không thể nhận diện giọng nói")
            return False, "Không nhận diện được giọng nói! Vui lòng nói rõ hơn.", ""
        except sr.RequestError as e:
            print(f"❌ Lỗi kết nối: {e}")
            return False, f"Lỗi kết nối Internet: {e}", ""
    
    def save_voice_sample(self, user_id, audio, sample_index):
        """Lưu mẫu giọng nói vào file"""
        os.makedirs(Config.VOICES_DIR, exist_ok=True)
        filename = f"{Config.VOICES_DIR}/{user_id}_voice_{sample_index}.wav"
        
        try:
            with wave.open(filename, 'wb') as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(16000)
                wf.writeframes(audio.get_wav_data())
            
            print(f"💾 Đã lưu file: {filename}")
            return filename
        except Exception as e:
            print(f"❌ Lỗi lưu file: {e}")
            return None
    
    def extract_voice_features(self, audio):
        """Trích xuất đặc trưng giọng nói"""
        try:
            audio_data = np.frombuffer(audio.get_wav_data(), dtype=np.int16)
            return {
                'duration': len(audio_data) / 16000,
                'rms_energy': np.sqrt(np.mean(audio_data**2)),
            }
        except Exception as e:
            print(f"❌ Lỗi trích xuất features: {e}")
            return {}