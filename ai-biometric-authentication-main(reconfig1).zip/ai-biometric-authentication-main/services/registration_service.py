from models.face_encoder import FaceEncoder
from models.voice_encoder import VoiceEncoder
from utils.database import UserDatabase
from config import Config

class RegistrationService:
    def __init__(self):
        self.face_encoder = FaceEncoder()
        self.voice_encoder = VoiceEncoder()
        self.database = UserDatabase()
    
    def register_new_user(self, user_id, user_info=None):
        """Đăng ký user mới"""
        return self.database.create_user(user_id, user_info or {})
    
    def register_face_sample(self, user_id, image):
        """Đăng ký mẫu khuôn mặt"""
        if not self.database.user_exists(user_id):
            return False, "User ID không tồn tại! Hãy tạo user trước."
        
        is_valid, message = self.face_encoder.validate_face_sample(image)
        if not is_valid:
            return False, message
        
        embedding = self.face_encoder.extract_face_embedding(image)
        if embedding is None:
            return False, "Không thể trích xuất đặc trưng khuôn mặt!"
        
        current_samples = self.database.get_user_info(user_id)['face_samples']
        filename = self.face_encoder.save_face_embedding(user_id, embedding, current_samples + 1)
        
        success, message = self.database.update_user_face(user_id, filename)
        return success, message
    
    def register_voice_sample(self, user_id):
        """Đăng ký mẫu giọng nói"""
        if not self.database.user_exists(user_id):
            return False, "User ID không tồn tại! Hãy tạo user trước."
        
        audio, success = self.voice_encoder.record_voice_sample()
        if not success:
            return False, "Lỗi micro! Vui lòng kiểm tra microphone."
        
        is_valid, message, recognized_text = self.voice_encoder.validate_voice_sample(audio)
        if not is_valid:
            return False, message
        
        current_samples = self.database.get_user_info(user_id)['voice_samples']
        filename = self.voice_encoder.save_voice_sample(user_id, audio, current_samples + 1)
        
        success, message = self.database.update_user_voice(user_id, filename)
        return success, message
    
    def get_user_registration_status(self, user_id):
        """Lấy trạng thái đăng ký của user"""
        return self.database.get_user_registration_status(user_id)
    
    def get_all_users(self):
        """Lấy danh sách tất cả users"""
        return self.database.get_all_users()
    
    def is_user_fully_registered(self, user_id):
        """Kiểm tra user đã đăng ký đầy đủ chưa"""
        status = self.get_user_registration_status(user_id)
        return status['fully_registered'] if status else False