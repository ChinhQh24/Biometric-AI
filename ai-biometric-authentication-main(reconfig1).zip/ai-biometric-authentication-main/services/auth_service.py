from models.face_verifier import FaceVerifier
from models.voice_verifier import VoiceVerifier
from utils.database import UserDatabase

class AuthService:
    def __init__(self):
        self.face_verifier = FaceVerifier()
        self.voice_verifier = VoiceVerifier()
        self.database = UserDatabase()
    
    def verify_user_face(self, image, user_id):
        """Xác thực khuôn mặt của user cụ thể"""
        if not self.database.user_exists(user_id):
            return False, 0, "User không tồn tại!"
        
        return self.face_verifier.verify_face(image, user_id)
    
    def verify_user_voice(self, user_id):
        """Xác thực giọng nói của user cụ thể"""
        if not self.database.user_exists(user_id):
            return False, "User không tồn tại!"
        
        return self.voice_verifier.verify_voice(user_id)
    
    def identify_face(self, image):
        """Nhận diện khuôn mặt từ tất cả users"""
        return self.face_verifier.identify_face(image)
    
    def identify_voice(self):
        """Nhận diện giọng nói từ tất cả users"""
        return self.voice_verifier.identify_voice()
    
    def multi_factor_auth(self, image, user_id):
        """Xác thực đa yếu tố: cả khuôn mặt và giọng nói"""
        face_success, face_confidence, face_message = self.verify_user_face(image, user_id)
        
        if not face_success:
            return False, f"Xác thực khuôn mặt thất bại: {face_message}"
        
        voice_success, voice_message = self.verify_user_voice(user_id)
        
        if not voice_success:
            return False, f"Xác thực giọng nói thất bại: {voice_message}"
        
        return True, f"Xác thực đa yếu tố thành công! Khuôn mặt: {face_confidence:.2f}"
    
    def get_user_auth_status(self, user_id):
        """Kiểm tra user đã đăng ký đủ dữ liệu để xác thực chưa"""
        if not self.database.user_exists(user_id):
            return None
        
        user_info = self.database.get_user_info(user_id)
        return {
            'user_id': user_id,
            'has_face_data': user_info['face_samples'] > 0,
            'has_voice_data': user_info['voice_samples'] > 0,
            'can_authenticate': user_info['face_samples'] > 0 or user_info['voice_samples'] > 0
        }
    
    def get_available_users(self):
        """Lấy danh sách users có thể xác thực"""
        # Làm mới dữ liệu trước khi lấy
        self.database.refresh_data()
        
        all_users = self.database.get_all_users()
        available_users = []
        
        for user_id in all_users:
            auth_status = self.get_user_auth_status(user_id)
            if auth_status and auth_status['can_authenticate']:
                available_users.append(user_id)
        
        return available_users